
var toggleButtons = document.querySelectorAll('.toggleButton');

toggleButtons.forEach(function(button) {
  button.addEventListener('click', function() {
    var info = this.nextElementSibling; 
    if (info.style.display === 'none' || info.style.display === '') {
      info.style.display = 'block';
    } else {
      info.style.display = 'none';
    }
  });
});